import classes from './WeatherInfo.module.css';

const WeatherInfo = props => {
    return (
        <div className={classes.WeatherInfo} >

        </div>
    )
}

export default WeatherInfo;